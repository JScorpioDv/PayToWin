/*
DDL Proyecto PAY TO WIN
------------------------

Nombre: Juan Pablo Sierra Amariles
Curso: 1ºDAW
*/

-- Creación de las tablas--
------------------------------

create table PROYECTO_usuario (
    nombreUsuario varchar2(30) primary key,
    nombreReal varchar2(40),
    correo varchar2(100) unique,
    passw varchar2(30),
    fnac date,
    tel number(13),
    ultconex date,
    tipo varchar2(20),
    foto varchar2(30)
);

create table PROYECTO_direccion (
    codigo number(35) primary key,
    calle varchar2(255),
    ciudad varchar2(100),
    provincia varchar2(100),
    cp number(5),
    pais varchar2(100),
    usuario varchar2(30) references PROYECTO_usuario,
    tipo varchar2(20)
);

create table PROYECTO_productos(
    abreviatura varchar2(1),
    codigo number(10) primary key,
    nombre varchar2(100),
    precio number(10,5),
    iva number(2),
    stockMinimo number (10),
    stock number(10),
    foto varchar2(255),
    usuarioCrea varchar2(30)references proyecto_usuario,
    fechacrea date,
    usuarioModif varchar2(30) references proyecto_usuario,
    fechamodif date,
    descripcion varchar2(500)
);

create table PROYECTO_pedido(
    codigo number(10) primary key,
    fecha date,
    metpago varchar2(100),
    facturado varchar2(2),
    direccion number(10) references PROYECTO_direccion,
    cliente varchar2(30) references PROYECTO_usuario
);

create table PROYECTO_lineaPedido(
    pedido number(10) references PROYECTO_pedido,
    productos number(10) references PROYECTO_productos,
    cantidad number(5),
    precio number(10,2),
    constraint pk_lineaPedido primary key (pedido, productos)
);

create table PROYECTO_factura(
    codigo number(10) primary key,
    fecha date,
    iva number(2),
    pedido number(10) unique references PROYECTO_pedido,
    direcFactura number(10) references PROYECTO_direccion
);

create table PROYECTO_categoria(
    codigo number(10) primary key,
    nombre varchar2(30)
);

create table PROYECTO_clasificacionProducto(
    productos number(10) references PROYECTO_productos,
    categoria number(10) references PROYECTO_categoria,
    constraint pk_clasificacionProducto primary key (productos, categoria)
);

--Restricciones check--
-------------------------

--Especificamos que el campo 'tipo' de la tabla usuario solo pueda ser Cliente o Admin.--
alter table PROYECTO_usuario modify check (tipo in ('Cliente','Admin'));

--Especificamos que el campo 'tipo' de la tabla direccion solo puede ser Envío o Facturación.--
alter table PROYECTO_direccion modify check (tipo in ('Envío','Facturación'));

--Especificamos que el campo 'facturado' de la tabla pedido solo pueda ser SI o NO.--
alter table PROYECTO_pedido modify check (facturado in ('SI','NO'));

--Especificamos que la fecha de Creación del producto debe ser mayor al 1 de enero de 2023.--
alter table PROYECTO_productos modify check (fechacrea > to_date('01/01/2023', 'DD/MM/YYYY'));

--Especificamos que el campo 'metpago' de la tabla pedido debe ser Tarjeta, Paypal y Bizum.--
alter table PROYECTO_pedido modify check (metpago in ('Tarjeta', 'Paypal', 'Bizum'));

--Eliminación de tablas--
---------------------------
/*drop table PROYECTO_clasificacionProducto;
drop table PROYECTO_categoria cascade constraints;
drop table PROYECTO_factura;
drop table PROYECTO_lineaPedido;
drop table PROYECTO_pedido cascade constraints;
drop table PROYECTO_productos cascade constraints;
drop table PROYECTO_direccion cascade constraints;
drop table PROYECTO_usuario cascade constraints;*/